const ChartJS = window.Chart;

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return <div className="p-8 text-center">Algo salió mal</div>;
    }
    return this.props.children;
  }
}

function DashboardApp() {
  try {
    const [currentPage, setCurrentPage] = React.useState('dashboard');
    const [user, setUser] = React.useState(null);

    React.useEffect(() => {
      const currentUser = requireAuth();
      setUser(currentUser);
    }, []);

    if (!user) return null;

    return (
      <div className="flex h-screen" data-name="dashboard-app" data-file="dashboard-app.js">
        <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} userRole={user.role} />
        <div className="flex-1 flex flex-col overflow-hidden">
          <Topbar user={user} />
          <main className="flex-1 overflow-y-auto p-6">
            <DashboardContent currentPage={currentPage} user={user} />
          </main>
        </div>
      </div>
    );
  } catch (error) {
    console.error('DashboardApp component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <DashboardApp />
  </ErrorBoundary>
);