function LoginForm({ onLoginSuccess }) {
  try {
    const [username, setUsername] = React.useState('');
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');
    const [loading, setLoading] = React.useState(false);

    const handleSubmit = async (e) => {
      e.preventDefault();
      setError('');
      setLoading(true);

      try {
        const user = await login(username, password);
        if (user) {
          onLoginSuccess();
        } else {
          setError('Usuario o contraseña incorrectos');
        }
      } catch (err) {
        setError('Error al iniciar sesión');
      } finally {
        setLoading(false);
      }
    };

    return (
      <div className="w-full max-w-md" data-name="login-form" data-file="components/LoginForm.js">
        <div className="bg-white rounded-2xl shadow-2xl p-8 backdrop-blur-lg">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-[var(--text-primary)] mb-2">Bienvenido</h2>
            <p className="text-[var(--text-secondary)]">Ingresa tus credenciales para continuar</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold mb-2 text-[var(--text-primary)]">Usuario</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <div className="icon-user text-lg text-[var(--text-secondary)]"></div>
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="input-field pl-12"
                  placeholder="Ingresa tu usuario"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2 text-[var(--text-primary)]">Contraseña</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <div className="icon-lock text-lg text-[var(--text-secondary)]"></div>
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input-field pl-12"
                  placeholder="Ingresa tu contraseña"
                  required
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border-2 border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm font-medium flex items-center gap-2">
                <div className="icon-alert-circle text-lg"></div>
                {error}
              </div>
            )}

            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="icon-loader-2 text-xl animate-spin"></div>
                  Iniciando...
                </span>
              ) : (
                'Iniciar Sesión'
              )}
            </button>
          </form>

          <div className="mt-8 p-5 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border-2 border-indigo-100">
            <p className="text-xs text-[var(--text-secondary)] mb-3 font-semibold flex items-center gap-2">
              <div className="icon-info text-sm"></div>
              Usuarios de prueba
            </p>
            <div className="text-xs space-y-2 text-[var(--text-secondary)]">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded font-medium">Superusuario</span>
                <span>super1/super123</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded font-medium">Admin</span>
                <span>admin1/admin123</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-green-100 text-green-700 rounded font-medium">Usuario</span>
                <span>user1/user123</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('LoginForm component error:', error);
    return null;
  }
}