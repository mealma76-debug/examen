function Sidebar({ currentPage, onPageChange, userRole }) {
  try {
    const menuItems = [
      { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
      { id: 'usuarios', label: 'Usuarios', icon: 'users' },
      { id: 'reportes', label: 'Reportes', icon: 'file-text' },
      { id: 'configuracion', label: 'Configuración', icon: 'settings' }
    ];

    return (
      <div className="w-64 bg-white border-r border-[var(--border-color)] flex flex-col shadow-lg" data-name="sidebar" data-file="components/Sidebar.js">
        <div className="p-6 border-b border-[var(--border-color)]">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] flex items-center justify-center shadow-md">
              <div className="icon-shield-check text-2xl text-white"></div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-[var(--text-primary)]">SysAdmin</h1>
              <p className="text-xs text-[var(--text-secondary)] font-medium">v2.0.1</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {menuItems.map(item => (
              <li key={item.id}>
                <button
                  onClick={() => onPageChange(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl transition-all duration-300 ${
                    currentPage === item.id
                      ? 'bg-gradient-to-r from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] text-white shadow-md transform scale-105'
                      : 'text-[var(--text-secondary)] hover:bg-[var(--secondary-color)] hover:text-[var(--primary-color)]'
                  }`}
                >
                  <div className={`icon-${item.icon} text-xl`}></div>
                  <span className="font-semibold">{item.label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="p-4 border-t border-[var(--border-color)]">
          <div className="px-4 py-3 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border-2 border-indigo-100">
            <p className="text-xs text-[var(--text-secondary)] mb-1 font-semibold">Rol actual</p>
            <p className="text-sm font-bold text-[var(--primary-color)] capitalize">{userRole}</p>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Sidebar component error:', error);
    return null;
  }
}