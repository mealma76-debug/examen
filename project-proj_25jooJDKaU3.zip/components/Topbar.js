function Topbar({ user }) {
  try {
    const [showNotifications, setShowNotifications] = React.useState(false);
    const [notifications] = React.useState([
      { id: 1, text: 'Nuevo usuario registrado', time: 'Hace 5 min' },
      { id: 2, text: 'Actualización del sistema completada', time: 'Hace 1 hora' },
      { id: 3, text: 'Reporte mensual disponible', time: 'Hace 2 horas' }
    ]);

    return (
      <div className="h-16 bg-white border-b border-[var(--border-color)] flex items-center justify-end px-6 gap-4 shadow-sm" data-name="topbar" data-file="components/Topbar.js">
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2.5 hover:bg-indigo-50 rounded-xl transition-all duration-300"
          >
            <div className="icon-bell text-xl text-[var(--text-secondary)]"></div>
            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border-2 border-white"></span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border-2 border-[var(--border-color)] z-50 overflow-hidden">
              <div className="p-4 bg-gradient-to-r from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] text-white">
                <h3 className="font-bold text-lg">Notificaciones</h3>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.map(notif => (
                  <div key={notif.id} className="p-4 hover:bg-indigo-50 border-b border-[var(--border-color)] cursor-pointer transition-all duration-200">
                    <p className="text-sm font-medium text-[var(--text-primary)]">{notif.text}</p>
                    <p className="text-xs text-[var(--text-secondary)] mt-1 flex items-center gap-1">
                      <div className="icon-clock text-xs"></div>
                      {notif.time}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3 pl-4 border-l-2 border-[var(--border-color)]">
          <div className="text-right">
            <p className="text-sm font-bold text-[var(--text-primary)]">{user.name}</p>
            <p className="text-xs text-[var(--text-secondary)] capitalize font-medium">{user.role}</p>
          </div>
          <button
            onClick={logout}
            className="p-2.5 hover:bg-red-50 rounded-xl transition-all duration-300 group"
            title="Cerrar sesión"
          >
            <div className="icon-log-out text-xl text-[var(--text-secondary)] group-hover:text-red-600"></div>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Topbar component error:', error);
    return null;
  }
}