function DashboardContent({ currentPage, user }) {
  try {
    if (currentPage === 'dashboard') {
      return <DashboardView />;
    } else if (currentPage === 'usuarios') {
      return <UsersView />;
    } else if (currentPage === 'reportes') {
      return <ReportsView />;
    } else if (currentPage === 'configuracion') {
      return <ConfigView />;
    }
    return null;
  } catch (error) {
    console.error('DashboardContent component error:', error);
    return null;
  }
}

function DashboardView() {
  const chartRef = React.useRef(null);
  const chartInstance = React.useRef(null);

  React.useEffect(() => {
    if (chartRef.current) {
      const ctx = chartRef.current.getContext('2d');
      
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      chartInstance.current = new ChartJS(ctx, {
        type: 'line',
        data: {
          labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
          datasets: [{
            label: 'Usuarios Activos',
            data: [30, 45, 38, 52, 48, 60],
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37, 99, 235, 0.1)',
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } }
        }
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, []);

  return (
    <div data-name="dashboard-view" data-file="components/DashboardContent.js">
      <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] hover:shadow-xl hover:border-[var(--primary-color)] transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-[var(--text-secondary)] mb-1 font-semibold">Total Usuarios</p>
              <h3 className="text-3xl font-bold text-[var(--text-primary)]">248</h3>
              <p className="text-xs text-green-600 mt-2 font-medium flex items-center gap-1">
                <div className="icon-trending-up text-sm"></div>
                12% vs mes anterior
              </p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg">
              <div className="icon-users text-2xl text-white"></div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] hover:shadow-xl hover:border-green-500 transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-[var(--text-secondary)] mb-1 font-semibold">Sesiones Activas</p>
              <h3 className="text-3xl font-bold text-[var(--text-primary)]">89</h3>
              <p className="text-xs text-green-600 mt-2 font-medium flex items-center gap-1">
                <div className="icon-trending-up text-sm"></div>
                8% vs ayer
              </p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-lg">
              <div className="icon-activity text-2xl text-white"></div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] hover:shadow-xl hover:border-purple-500 transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-[var(--text-secondary)] mb-1 font-semibold">Reportes</p>
              <h3 className="text-3xl font-bold text-[var(--text-primary)]">34</h3>
              <p className="text-xs text-blue-600 mt-2 font-medium flex items-center gap-1">
                <div className="icon-plus-circle text-sm"></div>
                5 nuevos hoy
              </p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center shadow-lg">
              <div className="icon-file-text text-2xl text-white"></div>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] hover:shadow-xl hover:border-orange-500 transition-all duration-300 transform hover:-translate-y-1">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-sm text-[var(--text-secondary)] mb-1 font-semibold">Tareas Pendientes</p>
              <h3 className="text-3xl font-bold text-[var(--text-primary)]">12</h3>
              <p className="text-xs text-orange-600 mt-2 font-medium flex items-center gap-1">
                <div className="icon-alert-circle text-sm"></div>
                3 urgentes
              </p>
            </div>
            <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 flex items-center justify-center shadow-lg">
              <div className="icon-check-square text-2xl text-white"></div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="icon-chart-bar text-xl text-[var(--primary-color)]"></div>
            Actividad Mensual
          </h3>
          <div style={{ height: '250px' }}>
            <canvas ref={chartRef}></canvas>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="icon-clock text-xl text-[var(--primary-color)]"></div>
            Actividad Reciente
          </h3>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-indigo-50 transition-all duration-200 border border-transparent hover:border-indigo-200">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center flex-shrink-0 shadow-md">
                <div className="icon-user-plus text-lg text-white"></div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-[var(--text-primary)]">Nuevo usuario registrado</p>
                <p className="text-xs text-[var(--text-secondary)] flex items-center gap-1 mt-1">
                  <div className="icon-clock text-xs"></div>
                  Hace 10 minutos
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 rounded-lg hover:bg-green-50 transition-all duration-200 border border-transparent hover:border-green-200">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center flex-shrink-0 shadow-md">
                <div className="icon-check text-lg text-white"></div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-[var(--text-primary)]">Tarea completada</p>
                <p className="text-xs text-[var(--text-secondary)] flex items-center gap-1 mt-1">
                  <div className="icon-clock text-xs"></div>
                  Hace 1 hora
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function UsersView() {
  const [users] = React.useState([
    { id: 1, name: 'Carlos Rodríguez', email: 'carlos@example.com', role: 'superuser', status: 'Activo' },
    { id: 2, name: 'María González', email: 'maria@example.com', role: 'superuser', status: 'Activo' },
    { id: 3, name: 'Juan Pérez', email: 'juan@example.com', role: 'admin', status: 'Activo' },
    { id: 4, name: 'Ana Martínez', email: 'ana@example.com', role: 'admin', status: 'Inactivo' },
    { id: 5, name: 'Pedro López', email: 'pedro@example.com', role: 'user', status: 'Activo' }
  ]);

  const getRoleBadge = (role) => {
    const styles = {
      superuser: 'bg-purple-100 text-purple-700',
      admin: 'bg-blue-100 text-blue-700',
      user: 'bg-green-100 text-green-700'
    };
    return styles[role] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div data-name="users-view" data-file="components/DashboardContent.js">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[var(--text-primary)]">Gestión de Usuarios</h1>
        <button className="px-4 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--accent-color)] transition-all flex items-center gap-2">
          <div className="icon-user-plus text-lg"></div>
          Nuevo Usuario
        </button>
      </div>

      <div className="bg-white rounded-xl border-2 border-[var(--border-color)] overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gradient-to-r from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] border-b-2 border-[var(--border-color)]">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">Usuario</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">Email</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">Rol</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">Estado</th>
                <th className="px-6 py-4 text-left text-xs font-bold text-white uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-color)]">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-indigo-50 transition-all duration-200">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-400 to-indigo-600 flex items-center justify-center shadow-md">
                        <div className="icon-user text-xl text-white"></div>
                      </div>
                      <span className="font-semibold text-[var(--text-primary)]">{user.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-[var(--text-secondary)]">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${getRoleBadge(user.role)}`}>
                      {user.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${user.status === 'Activo' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex gap-2">
                      <button className="p-2.5 hover:bg-blue-100 rounded-xl transition-all duration-200 group" title="Editar">
                        <div className="icon-pencil text-lg text-[var(--primary-color)] group-hover:scale-110 transition-transform"></div>
                      </button>
                      <button className="p-2.5 hover:bg-red-100 rounded-xl transition-all duration-200 group" title="Eliminar">
                        <div className="icon-trash-2 text-lg text-red-600 group-hover:scale-110 transition-transform"></div>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function ReportsView() {
  const [reports] = React.useState([
    { id: 1, title: 'Reporte Mensual de Usuarios', date: '2025-11-15', type: 'PDF', size: '2.4 MB' },
    { id: 2, title: 'Análisis de Actividad', date: '2025-11-10', type: 'Excel', size: '1.8 MB' },
    { id: 3, title: 'Auditoría de Seguridad', date: '2025-11-05', type: 'PDF', size: '3.2 MB' },
    { id: 4, title: 'Informe de Rendimiento', date: '2025-11-01', type: 'PDF', size: '1.5 MB' }
  ]);

  return (
    <div data-name="reports-view" data-file="components/DashboardContent.js">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[var(--text-primary)]">Reportes</h1>
        <button className="px-4 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--accent-color)] transition-all flex items-center gap-2">
          <div className="icon-plus text-lg"></div>
          Generar Reporte
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reports.map(report => (
          <div key={report.id} className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] hover:shadow-xl hover:border-[var(--primary-color)] transition-all duration-300 transform hover:-translate-y-1">
            <div className="flex items-start justify-between mb-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center shadow-lg">
                <div className="icon-file-text text-2xl text-white"></div>
              </div>
              <span className="text-xs px-3 py-1.5 bg-gradient-to-r from-indigo-100 to-purple-100 text-[var(--primary-color)] rounded-lg font-semibold">{report.type}</span>
            </div>
            <h3 className="font-bold text-[var(--text-primary)] mb-3 text-lg">{report.title}</h3>
            <div className="flex items-center gap-4 text-xs text-[var(--text-secondary)] mb-4 font-medium">
              <span className="flex items-center gap-1">
                <div className="icon-calendar text-sm"></div>
                {report.date}
              </span>
              <span className="flex items-center gap-1">
                <div className="icon-hard-drive text-sm"></div>
                {report.size}
              </span>
            </div>
            <div className="flex gap-2">
              <button className="flex-1 px-4 py-2.5 bg-gradient-to-r from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] text-white rounded-lg hover:shadow-lg transition-all text-sm font-semibold transform hover:scale-105">
                Descargar
              </button>
              <button className="px-4 py-2.5 border-2 border-[var(--border-color)] rounded-lg hover:bg-indigo-50 hover:border-[var(--primary-color)] transition-all">
                <div className="icon-eye text-lg text-[var(--text-secondary)]"></div>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ConfigView() {
  const [config, setConfig] = React.useState({
    siteName: 'SysAdmin',
    siteVersion: 'v2.0.1',
    emailNotifications: true,
    twoFactorAuth: false,
    maintenanceMode: false,
    maxLoginAttempts: 3
  });

  return (
    <div data-name="config-view" data-file="components/DashboardContent.js">
      <h1 className="text-2xl font-bold text-[var(--text-primary)] mb-6">Configuración del Sistema</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-md">
              <div className="icon-settings text-lg text-white"></div>
            </div>
            Información General
          </h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Nombre del Sistema</label>
              <input
                type="text"
                value={config.siteName}
                onChange={(e) => setConfig({...config, siteName: e.target.value})}
                className="w-full px-4 py-2 border border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Versión</label>
              <input
                type="text"
                value={config.siteVersion}
                onChange={(e) => setConfig({...config, siteVersion: e.target.value})}
                className="w-full px-4 py-2 border border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-md">
              <div className="icon-shield text-lg text-white"></div>
            </div>
            Seguridad
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-[var(--text-primary)]">Autenticación de dos factores</p>
                <p className="text-sm text-[var(--text-secondary)]">Requiere código adicional al iniciar sesión</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.twoFactorAuth}
                  onChange={(e) => setConfig({...config, twoFactorAuth: e.target.checked})}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:ring-2 peer-focus:ring-[var(--primary-color)] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--primary-color)]"></div>
              </label>
            </div>
            <div>
              <label className="block text-sm font-medium text-[var(--text-primary)] mb-2">Intentos máximos de login</label>
              <input
                type="number"
                value={config.maxLoginAttempts}
                onChange={(e) => setConfig({...config, maxLoginAttempts: parseInt(e.target.value)})}
                className="w-full px-4 py-2 border border-[var(--border-color)] rounded-lg focus:ring-2 focus:ring-[var(--primary-color)] focus:border-transparent"
              />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-yellow-400 to-orange-600 flex items-center justify-center shadow-md">
              <div className="icon-bell text-lg text-white"></div>
            </div>
            Notificaciones
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-[var(--text-primary)]">Notificaciones por email</p>
                <p className="text-sm text-[var(--text-secondary)]">Recibir alertas del sistema por correo</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.emailNotifications}
                  onChange={(e) => setConfig({...config, emailNotifications: e.target.checked})}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:ring-2 peer-focus:ring-[var(--primary-color)] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--primary-color)]"></div>
              </label>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border-2 border-[var(--border-color)] shadow-lg hover:shadow-xl transition-all duration-300">
          <h3 className="text-lg font-bold text-[var(--text-primary)] mb-4 flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-400 to-purple-600 flex items-center justify-center shadow-md">
              <div className="icon-wrench text-lg text-white"></div>
            </div>
            Mantenimiento
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-[var(--text-primary)]">Modo mantenimiento</p>
                <p className="text-sm text-[var(--text-secondary)]">Desactiva el acceso temporalmente</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.maintenanceMode}
                  onChange={(e) => setConfig({...config, maintenanceMode: e.target.checked})}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:ring-2 peer-focus:ring-[var(--primary-color)] rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[var(--primary-color)]"></div>
              </label>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <button className="px-8 py-3.5 bg-gradient-to-r from-[var(--bg-gradient-start)] to-[var(--bg-gradient-end)] text-white rounded-xl hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 font-semibold flex items-center gap-2">
          <div className="icon-save text-lg"></div>
          Guardar Cambios
        </button>
      </div>
    </div>
  );
}
