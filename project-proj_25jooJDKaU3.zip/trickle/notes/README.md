# Sistema de Gestión con Control de Roles

Sistema administrativo completo con control de acceso basado en roles y gestión de usuarios.

## Características Principales

- **Sistema de Login** con diseño dividido elegante
- **Control de Roles**: Superusuario, Administrador y Usuario
- **Dashboard Interactivo** con estadísticas y gráficas en tiempo real
- **Gestión de Usuarios** con tabla completa
- **Sistema de Reportes** con generación y descarga
- **Configuración del Sistema** con múltiples opciones

## Estructura del Proyecto

- `index.html` - Página de login
- `dashboard.html` - Panel de control principal
- `app.js` - Lógica principal del login
- `dashboard-app.js` - Lógica del dashboard
- `components/` - Componentes React reutilizables
- `utils/` - Utilidades (autenticación, etc.)

## Usuarios de Prueba

### Superusuarios
- **Usuario**: super1 | **Contraseña**: super123
- **Usuario**: super2 | **Contraseña**: super123

### Administradores
- **Usuario**: admin1 | **Contraseña**: admin123
- **Usuario**: admin2 | **Contraseña**: admin123

### Usuarios Regulares
- **Usuario**: user1 | **Contraseña**: user123
- **Usuario**: user2 | **Contraseña**: user123

## Secciones del Dashboard

1. **Dashboard**: Vista general con 4 tarjetas de estadísticas y gráficas
2. **Usuarios**: Gestión completa de usuarios con tabla
3. **Reportes**: Sistema de reportes con descarga
4. **Configuración**: Ajustes del sistema y seguridad

## Versión

Sistema v2.0.1 - © 2025