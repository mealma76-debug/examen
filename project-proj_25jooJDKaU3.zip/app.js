class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('ErrorBoundary caught an error:', error, errorInfo.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Algo salió mal</h1>
            <p className="text-gray-600 mb-4">Por favor, recarga la página.</p>
            <button onClick={() => window.location.reload()} className="btn-primary">
              Recargar Página
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function App() {
  try {
    const [isAuthenticated, setIsAuthenticated] = React.useState(false);

    React.useEffect(() => {
      const user = getCurrentUser();
      if (user) {
        window.location.href = 'dashboard.html';
      }
    }, []);

    const handleLoginSuccess = () => {
      window.location.href = 'dashboard.html';
    };

    return (
      <div className="min-h-screen flex" data-name="app" data-file="app.js">
        <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-[var(--bg-gradient-start)] via-[var(--primary-color)] to-[var(--bg-gradient-end)] p-12 items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-5"></div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-white opacity-5 rounded-full -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white opacity-5 rounded-full -ml-48 -mb-48"></div>
          <div className="text-white max-w-md relative z-10">
            <div className="w-20 h-20 bg-white bg-opacity-20 rounded-2xl flex items-center justify-center mb-8 backdrop-blur-sm">
              <div className="icon-shield-check text-5xl"></div>
            </div>
            <h1 className="text-5xl font-bold mb-4 leading-tight">Sistema de Gestión</h1>
            <p className="text-xl text-indigo-100 mb-8 leading-relaxed">Control total de versiones y roles de usuario</p>
            <div className="space-y-5">
              <div className="flex items-start gap-4 bg-white bg-opacity-10 p-4 rounded-xl backdrop-blur-sm">
                <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <div className="icon-check-circle text-xl"></div>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Multi-rol</h3>
                  <p className="text-indigo-100 text-sm">Superusuario, Administrador y Usuario</p>
                </div>
              </div>
              <div className="flex items-start gap-4 bg-white bg-opacity-10 p-4 rounded-xl backdrop-blur-sm">
                <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <div className="icon-database text-xl"></div>
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Base de datos</h3>
                  <p className="text-indigo-100 text-sm">Gestión completa de registros</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
          <LoginForm onLoginSuccess={handleLoginSuccess} />
        </div>
      </div>
    );
  } catch (error) {
    console.error('App component error:', error);
    return null;
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);