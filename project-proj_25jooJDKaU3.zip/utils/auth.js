const USERS_DB = [
  { id: 1, username: 'super1', password: 'super123', role: 'superuser', name: 'Carlos Rodríguez' },
  { id: 2, username: 'super2', password: 'super123', role: 'superuser', name: 'María González' },
  { id: 3, username: 'admin1', password: 'admin123', role: 'admin', name: 'Juan Pérez' },
  { id: 4, username: 'admin2', password: 'admin123', role: 'admin', name: 'Ana Martínez' },
  { id: 5, username: 'user1', password: 'user123', role: 'user', name: 'Pedro López' },
  { id: 6, username: 'user2', password: 'user123', role: 'user', name: 'Laura Sánchez' }
];

function login(username, password) {
  return new Promise((resolve) => {
    setTimeout(() => {
      const user = USERS_DB.find(u => u.username === username && u.password === password);
      if (user) {
        const userSession = { ...user };
        delete userSession.password;
        localStorage.setItem('currentUser', JSON.stringify(userSession));
        resolve(userSession);
      } else {
        resolve(null);
      }
    }, 500);
  });
}

function logout() {
  localStorage.removeItem('currentUser');
  window.location.href = 'index.html';
}

function getCurrentUser() {
  const userStr = localStorage.getItem('currentUser');
  return userStr ? JSON.parse(userStr) : null;
}

function requireAuth() {
  const user = getCurrentUser();
  if (!user) {
    window.location.href = 'index.html';
    return null;
  }
  return user;
}